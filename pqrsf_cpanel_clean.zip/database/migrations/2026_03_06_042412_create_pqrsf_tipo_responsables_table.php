<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('pqrsf_tipo_responsables', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('pqrsf_tipo_id')->constrained('pqrsf_tipos')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['pqrsf_tipo_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pqrsf_tipo_responsables');
    }
};
